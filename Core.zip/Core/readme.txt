core python scripts

